// In mongo it has a default variable db which refers to the 
// current database you are in so it needs to be redirected to test
// res is a variable to store our results
db = db.getSisterDB("test");
var res = null;




// this is to check if the cluster is ready for sharding
// if it fails it stops and waits for things to load and trys again
res = sh.enableSharding("test");
while (res.ok != 1) {
    sleep(10);
    if (res.ok != 1){
        print("Enable test for Sharding Failed. Trying it again");
        res = sh.enableSharding("test");
    }
}
print("test Enable for Sharding!");


// this is for defining our indexes
// again if it fails it pauses and trys again
res = db.restaurants.createIndex({ "Hospital_code" : 1, "Department" : 1 });
while (res.ok != 1) {
    sleep(10);
    if (res.ok != 1){
        print("Creating index for covid_hospital_treatment_plan collection failed. Trying it again");
        res = db.restaurants.createIndex({ "Hospital_code" : 1, "Department" : 1 });
    }
}
print("covid_hospital_treatment_plan Collection Index Created!");

// this creates our shard keys
// again if it fails it stops and trys again
res = sh.shardCollection("test.covid_hospital_treatment_plan", { "Hospital_code" : 1, "Department" : 1 } );
while (res.ok != 1) {
    sleep(10);
    if (res.ok != 1){
        print("Sharding covid_hospital_treatment_plan collection failed. Trying it again");
        res = sh.shardCollection("test.covid_hospital_treatment_plan", { "Hospital_code" : 1, "Department" : 1 } );
    }
}
print("covid_hospital_treatment_plan Collection Sharded!");


// watch what happens
for (i = 0; i < 1000; i++) {
    sh.status();
    sleep(100);
}

//quit
quit()


