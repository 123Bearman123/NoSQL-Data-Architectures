// Here we  create the replica set and initiate them
var host = "localhost";
db = db.getSisterDB("config");
var mongosConn = db;
var res = null;
db.settings.save( { _id:"chunksize", value: 1 } )
db = connect(host+":26050/config");
res = rs.initiate(
    {
        "_id" : "configServers",
        "members" : [
            { _id:0, host: host+":"+"26050" },
            { _id:1, host: host+":"+"26051" },
            { _id:2, host: host+":"+"26052" }
        ]
    }
);
while (res.ok != 1){
    sleep(10);
}
print("ConfigServers Replica Set Created!");
while (((rs.status().members[0].state != 1) && (rs.status().members[0].state != 2)) || ((rs.status().members[1].state != 1) && (rs.status().members[1].state != 2)) || ((rs.status().members[2].state != 1) && (rs.status().members[2].state != 2))) {
    sleep(10);
}
print("ConfigServers Replica Set Up!");
quit()