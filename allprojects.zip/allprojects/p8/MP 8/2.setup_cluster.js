// Here we  create the shards and initiate them

//We set a variable  host which points to the local host
var host = "localhost";

// In mongo it has a default variable db which refers to the 
// current database you are in so it needs to be redirected
// In he config databases it stores the metadata( configuration of the entire cluster)
// we need the copy of the metadata from config to mongosConn
// basically you connect your mongos to your databases for the config server so you can transer data
// We need a variable for the results of the setup of the replica set for each data centre
db = db.getSisterDB("config");
var mongosConn = db;
var res = null;


// Here we set the chunk size
// It is set by default but its to big and we wont be able to see what is happening
// db is in our databse config which has settings for connections
// One of these being a file chunksize which we use and set to 1
db.settings.save( { _id:"chunksize", value: 1 } )


// X
// connect to the mongod process within config
// connect our shard with our databse
// host is our localhost
db = connect(host+":27000/test");

// set up of the replica set, rs stores this info
// .initiate  stars to setup the shard/node as the primary node
// within we setup the replica set and add the secondary into it

res = rs.initiate(
    {
        "_id" : "regionx",
        "members" : [
            { _id:0,host:host+":"+"27000" },
            { _id:1,host:host+":"+"27001" },
            { _id:2,host:host+":"+"27002" }
        ]
    }
);

// delay to allow if replica set fails and it goes again
while (res.ok != 1){
    sleep(10);
}
print("Regionx Replica Set Created!");
// go through each member and check each node to make sure its not a fail
while (((rs.status().members[0].state != 1) && (rs.status().members[0].state != 2)) || ((rs.status().members[1].state != 1) && (rs.status().members[1].state != 2)) || ((rs.status().members[2].state != 1) && (rs.status().members[2].state != 2))) {
    sleep(10);
}
print("Regionx Replica Set Up!");

// then we add the shards, we connect the database/replica set to mongos// 
db = mongosConn;
// we add all of X as the replica set and the startuing node and add as a shard
res = sh.addShard("regionx/"+host+":27000");
// if fails it sleeps and try again
while (res.ok != 1){
    sleep(60);
    if (res.ok != 1){
        print("Adding Shard Failed. Trying it again");
        res = sh.addShard("regionx/"+host+":27000");
    }
}
print("Regionx Shard Added!");




// Y
db = connect(host+":27100/test");
res = rs.initiate(
    {
        "_id" : "regiony",
        "members" : [
            { _id:0,host:host+":"+"27100" },
            { _id:1,host:host+":"+"27101" },
            { _id:2,host:host+":"+"27102" }
        ]
    }
);
while (res.ok != 1){
    sleep(10);
}
print("Regiony Replica Set Created!");
while (((rs.status().members[0].state != 1) && (rs.status().members[0].state != 2)) || ((rs.status().members[1].state != 1) && (rs.status().members[1].state != 2)) || ((rs.status().members[2].state != 1) && (rs.status().members[2].state != 2))) {
    sleep(10);
}
print("Regiony Replica Set Up!");
db = mongosConn;
res = sh.addShard("regiony/"+host+":27100");
while (res.ok != 1){
    sleep(60);
    if (res.ok != 1){
        print("Adding Shard Failed. Trying it again");
        res = sh.addShard("regiony/"+host+":27100");
    }
}
print("Regiony Shard Added!");



//Z
db = connect(host+":27200/test");
res = rs.initiate(
    {
        "_id" : "regionz",
        "members" : [
            { _id:0,host:host+":"+"27200" },
            { _id:1,host:host+":"+"27201" },
            { _id:2,host:host+":"+"27202" }
        ]
    }
);
while (res.ok != 1){
    sleep(10);
}
print("Regionz Replica Set Created!");
while (((rs.status().members[0].state != 1) && (rs.status().members[0].state != 2)) || ((rs.status().members[1].state != 1) && (rs.status().members[1].state != 2)) || ((rs.status().members[2].state != 1) && (rs.status().members[2].state != 2))) {
    sleep(10);
}
print("Regionz Replica Set Up!");
db = mongosConn;
res = sh.addShard("regionz/"+host+":27200");
while (res.ok != 1){
    sleep(60);
    if (res.ok != 1){
        print("Adding Shard Failed. Trying it again");
        res = sh.addShard("regionz/"+host+":27200");
    }
}
print("Regionz Shard Added!");
quit()
